#include <iostream>
#include <vector>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <string>
#include <immintrin.h>  // �����ִ� CPU ָ�֧�֣����� SSE, SSSE3, AES-NI �ȣ�
using namespace std;

/*
 * �ڴ�����ʮ�����Ƹ�ʽ�����
 * ���ڵ��Խ׶ε����ġ����ļ�״̬����Ŀ��ӻ��˶�
 */
void printHex(const string& label, const uint8_t* data, size_t length) {
    cout << label << " (" << length << " bytes):" << endl;
    for (size_t i = 0; i < length; i++) {
        // ǿ�ư����ַ����������ʮ���������
        cout << hex << setw(2) << setfill('0') << (int)data[i] << " ";
        if ((i + 1) % 16 == 0) {
            cout << endl;
        }
    }
    cout << dec << endl;
}

/*
 * AES ����ʵ�ֲ�Ϊ���� T-table (�����) ���Ż�����
 * �����ͼ������ AES-NI Ӳ��ָ�֧�ֵ��Ͼɻ�Ƕ��ʽ�ܹ��ϣ�
 * ͨ��Ԥ���㽫 SubBytes��ShiftRows �� MixColumns �ں�Ϊ 32 λ��������
 */
class AESTableOpt {
private:
    uint32_t T0[256], T1[256], T2[256], T3[256];
    uint32_t rk[44]; // AES-128 ��չ��Կ��44��32λ�֣�

    const uint8_t SBOX[256] = {
        0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
        0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
        0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
        0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
        0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
        0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
        0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
        0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
        0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
        0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
        0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
        0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
        0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
        0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
        0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
        0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
    };

    uint8_t mul2(uint8_t a) { return (a & 0x80) ? ((a << 1) ^ 0x1B) : (a << 1); }
    uint8_t mul3(uint8_t a) { return mul2(a) ^ a; }

public:
    AESTableOpt() {
        // T-table ��ʼ��
        for (int i = 0; i < 256; i++) {
            uint8_t s = SBOX[i], s2 = mul2(s), s3 = mul3(s);
            T0[i] = (s2 << 24) | (s << 16) | (s << 8) | s3;
            T1[i] = (s3 << 24) | (s2 << 16) | (s << 8) | s;
            T2[i] = (s << 24) | (s3 << 16) | (s2 << 8) | s;
            T3[i] = (s << 24) | (s << 16) | (s3 << 8) | s2;
        }
    }

    /* ����ʵ�ְ���Կ���� */
    void SetKey(const uint8_t* key) {
        for (int i = 0; i < 4; i++) {
            rk[i] = (key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3];
        }
        const uint32_t RCON[10] = { 0x01000000, 0x02000000, 0x04000000, 0x08000000, 0x10000000,
                                    0x20000000, 0x40000000, 0x80000000, 0x1B000000, 0x36000000 };
        for (int i = 4; i < 44; i++) {
            uint32_t temp = rk[i - 1];
            if (i % 4 == 0) {
                uint32_t rot = (temp << 8) | (temp >> 24); // RotWord
                temp = (SBOX[(rot >> 24) & 0xFF] << 24) | (SBOX[(rot >> 16) & 0xFF] << 16) |
                    (SBOX[(rot >> 8) & 0xFF] << 8) | SBOX[rot & 0xFF]; // SubWord
                temp ^= RCON[i / 4 - 1];
            }
            rk[i] = rk[i - 4] ^ temp;
        }
    }

    /* ������ܺ� (T-table) */
    void encryptBlock(const uint8_t* in, uint8_t* out) {
        // ��ȡ���벢��ܶ������⣬ת���ڲ�������ʾ
        uint32_t s0 = (in[0] << 24) | (in[1] << 16) | (in[2] << 8) | in[3];
        uint32_t s1 = (in[4] << 24) | (in[5] << 16) | (in[6] << 8) | in[7];
        uint32_t s2 = (in[8] << 24) | (in[9] << 16) | (in[10] << 8) | in[11];
        uint32_t s3 = (in[12] << 24) | (in[13] << 16) | (in[14] << 8) | in[15];

        s0 ^= rk[0]; s1 ^= rk[1]; s2 ^= rk[2]; s3 ^= rk[3];

        // 1-9�ֻ��� T-table ������ֺ���
        for (int r = 1; r < 10; r++) {
            uint32_t t0 = T0[(s0 >> 24) & 0xFF] ^ T1[(s1 >> 16) & 0xFF] ^ T2[(s2 >> 8) & 0xFF] ^ T3[s3 & 0xFF] ^ rk[r * 4];
            uint32_t t1 = T0[(s1 >> 24) & 0xFF] ^ T1[(s2 >> 16) & 0xFF] ^ T2[(s3 >> 8) & 0xFF] ^ T3[s0 & 0xFF] ^ rk[r * 4 + 1];
            uint32_t t2 = T0[(s2 >> 24) & 0xFF] ^ T1[(s3 >> 16) & 0xFF] ^ T2[(s0 >> 8) & 0xFF] ^ T3[s1 & 0xFF] ^ rk[r * 4 + 2];
            uint32_t t3 = T0[(s3 >> 24) & 0xFF] ^ T1[(s0 >> 16) & 0xFF] ^ T2[(s1 >> 8) & 0xFF] ^ T3[s2 & 0xFF] ^ rk[r * 4 + 3];
            s0 = t0; s1 = t1; s2 = t2; s3 = t3;
        }

        // ��10��ĩ�����⴦�� (�� MixColumns)
        uint32_t out0 = (SBOX[(s0 >> 24) & 0xFF] << 24) | (SBOX[(s1 >> 16) & 0xFF] << 16) | (SBOX[(s2 >> 8) & 0xFF] << 8) | SBOX[s3 & 0xFF];
        uint32_t out1 = (SBOX[(s1 >> 24) & 0xFF] << 24) | (SBOX[(s2 >> 16) & 0xFF] << 16) | (SBOX[(s3 >> 8) & 0xFF] << 8) | SBOX[s0 & 0xFF];
        uint32_t out2 = (SBOX[(s2 >> 24) & 0xFF] << 24) | (SBOX[(s3 >> 16) & 0xFF] << 16) | (SBOX[(s0 >> 8) & 0xFF] << 8) | SBOX[s1 & 0xFF];
        uint32_t out3 = (SBOX[(s3 >> 24) & 0xFF] << 24) | (SBOX[(s0 >> 16) & 0xFF] << 16) | (SBOX[(s1 >> 8) & 0xFF] << 8) | SBOX[s2 & 0xFF];

        out0 ^= rk[40]; out1 ^= rk[41]; out2 ^= rk[42]; out3 ^= rk[43];

        out[0] = out0 >> 24; out[1] = out0 >> 16; out[2] = out0 >> 8; out[3] = out0;
        out[4] = out1 >> 24; out[5] = out1 >> 16; out[6] = out1 >> 8; out[7] = out1;
        out[8] = out2 >> 24; out[9] = out2 >> 16; out[10] = out2 >> 8; out[11] = out2;
        out[12] = out3 >> 24; out[13] = out3 >> 16; out[14] = out3 >> 8; out[15] = out3;
    }

    /* ����ģʽ�µ� CTR ʵ�֣��������ܻ�׼�Ա� */
    void EncryptCTR(const uint8_t* in, uint8_t* out, size_t length, const uint8_t* iv) {
        uint8_t counter[16];
        memcpy(counter, iv, 16);
        uint8_t stream[16];
        size_t i = 0;

        while (i < length) {
            encryptBlock(counter, stream);
            size_t block_len = (length - i < 16) ? (length - i) : 16;

            for (size_t j = 0; j < block_len; j++) {
                out[i + j] = in[i + j] ^ stream[j];
            }
            i += block_len;

            // ����� Counter �����߼�
            for (int k = 15; k >= 0; k--) {
                if (++counter[k]) break;
            }
        }
    }
};

/*
 * ����Ӳ��ָ� (AES-NI + SSSE3 Shuffle) �� CTR ģʽ�����Ż�ʵ��
 * �����Ż�Ҫ������Ӳ��ָ� (AES-NI) + ����չ�� (Shuffle pshufb) + 4·ѭ��չ��
 */
class AES_NI_CTR_Optimized {
private:
    __m128i round_keys[11];

    inline __m128i key_expand(__m128i key, __m128i keygened) {
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        key = _mm_xor_si128(key, _mm_slli_si128(key, 4));
        keygened = _mm_shuffle_epi32(keygened, _MM_SHUFFLE(3, 3, 3, 3));
        return _mm_xor_si128(key, keygened);
    }

public:
    void SetKey(const uint8_t* key) {
        round_keys[0] = _mm_loadu_si128((const __m128i*)key);
        round_keys[1] = key_expand(round_keys[0], _mm_aeskeygenassist_si128(round_keys[0], 0x01));
        round_keys[2] = key_expand(round_keys[1], _mm_aeskeygenassist_si128(round_keys[1], 0x02));
        round_keys[3] = key_expand(round_keys[2], _mm_aeskeygenassist_si128(round_keys[2], 0x04));
        round_keys[4] = key_expand(round_keys[3], _mm_aeskeygenassist_si128(round_keys[3], 0x08));
        round_keys[5] = key_expand(round_keys[4], _mm_aeskeygenassist_si128(round_keys[4], 0x10));
        round_keys[6] = key_expand(round_keys[5], _mm_aeskeygenassist_si128(round_keys[5], 0x20));
        round_keys[7] = key_expand(round_keys[6], _mm_aeskeygenassist_si128(round_keys[6], 0x40));
        round_keys[8] = key_expand(round_keys[7], _mm_aeskeygenassist_si128(round_keys[7], 0x80));
        round_keys[9] = key_expand(round_keys[8], _mm_aeskeygenassist_si128(round_keys[8], 0x1B));
        round_keys[10] = key_expand(round_keys[9], _mm_aeskeygenassist_si128(round_keys[9], 0x36));
    }

    void EncryptCTR_4x(const uint8_t* in, uint8_t* out, size_t length, const uint8_t* iv) {
        // �����Ż�ΪSSSE3 Shuffle (pshufb) �ֽڷ�ת����
        // ��Ч�������� Counter �� x86 С����Ĵ�������ĳ�ͻ
        __m128i bswap_mask = _mm_setr_epi8(15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0);

        __m128i ctr = _mm_loadu_si128((const __m128i*)iv);
        // Shuffle ��ת����������(Big-Endian)תΪ����Ӳ������� Little-Endian
        ctr = _mm_shuffle_epi8(ctr, bswap_mask);

        __m128i one = _mm_set_epi64x(0, 1);

        size_t i = 0;
        // 4·ѭ��չ�� (4-Way Loop Unrolling) ��ˮ�����
        while (i + 64 <= length) {
            // ���� shuffle ��������ļ�����ת�ؼ���״̬Ҫ��Ĵ����
            __m128i c0 = _mm_shuffle_epi8(ctr, bswap_mask);
            ctr = _mm_add_epi64(ctr, one); // Ӳ�����ӷ�
            __m128i c1 = _mm_shuffle_epi8(ctr, bswap_mask);
            ctr = _mm_add_epi64(ctr, one);
            __m128i c2 = _mm_shuffle_epi8(ctr, bswap_mask);
            ctr = _mm_add_epi64(ctr, one);
            __m128i c3 = _mm_shuffle_epi8(ctr, bswap_mask);
            ctr = _mm_add_epi64(ctr, one);

            // �������Կ
            c0 = _mm_xor_si128(c0, round_keys[0]);
            c1 = _mm_xor_si128(c1, round_keys[0]);
            c2 = _mm_xor_si128(c2, round_keys[0]);
            c3 = _mm_xor_si128(c3, round_keys[0]);

            // AES ������ָ���ɷ� 
            for (int r = 1; r < 10; ++r) {
                c0 = _mm_aesenc_si128(c0, round_keys[r]);
                c1 = _mm_aesenc_si128(c1, round_keys[r]);
                c2 = _mm_aesenc_si128(c2, round_keys[r]);
                c3 = _mm_aesenc_si128(c3, round_keys[r]);
            }

            // AES ĩ��
            c0 = _mm_aesenclast_si128(c0, round_keys[10]);
            c1 = _mm_aesenclast_si128(c1, round_keys[10]);
            c2 = _mm_aesenclast_si128(c2, round_keys[10]);
            c3 = _mm_aesenclast_si128(c3, round_keys[10]);

            // �������������������
            c0 = _mm_xor_si128(c0, _mm_loadu_si128((const __m128i*)(in + i)));
            c1 = _mm_xor_si128(c1, _mm_loadu_si128((const __m128i*)(in + i + 16)));
            c2 = _mm_xor_si128(c2, _mm_loadu_si128((const __m128i*)(in + i + 32)));
            c3 = _mm_xor_si128(c3, _mm_loadu_si128((const __m128i*)(in + i + 48)));

            // �����ڴ�
            _mm_storeu_si128((__m128i*)(out + i), c0);
            _mm_storeu_si128((__m128i*)(out + i + 16), c1);
            _mm_storeu_si128((__m128i*)(out + i + 32), c2);
            _mm_storeu_si128((__m128i*)(out + i + 48), c3);

            i += 64;
        }

        // β���˻������������� 64 �ֽڱ������֣�
        while (i < length) {
            __m128i c = _mm_shuffle_epi8(ctr, bswap_mask);
            ctr = _mm_add_epi64(ctr, one);
            c = _mm_xor_si128(c, round_keys[0]);
            for (int r = 1; r < 10; ++r) c = _mm_aesenc_si128(c, round_keys[r]);
            c = _mm_aesenclast_si128(c, round_keys[10]);

            uint8_t tmp[16];
            _mm_storeu_si128((__m128i*)tmp, c);

            for (size_t j = 0; j < 16 && (i + j) < length; ++j) {
                out[i + j] = in[i + j] ^ tmp[j];
            }
            i += 16;
        }
    }
};

int main() {
    AESTableOpt aes_table;
    AES_NI_CTR_Optimized aes_ni;

    uint8_t key[16] = { 0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c };
    uint8_t iv[16] = { 0xf0,0xf1,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,0xf8,0xf9,0xfa,0xfb,0xfc,0xfd,0xfe,0xff };

    uint8_t plaintext[64];
    for (int i = 0; i < 64; ++i) plaintext[i] = static_cast<uint8_t>(i);

    uint8_t hw_ciphertext[64];
    uint8_t sw_ciphertext[64];
    uint8_t decrypted[64];

    cout << "AES�ӽ���˫·���Ż���֤��" << endl;
    printHex("ԭʼ����", plaintext, 64);

    // T-table �����Ż�ʵ����֤
    aes_table.SetKey(key);
    aes_table.EncryptCTR(plaintext, sw_ciphertext, 64, iv);
    printHex("T-table �������� CTR ���ܽ��", sw_ciphertext, 64);

    // AES-NI Ӳ���Ż�ʵ����֤
    aes_ni.SetKey(key);
    aes_ni.EncryptCTR_4x(plaintext, hw_ciphertext, 64, iv);
    printHex("AES-NI + SSSE3(Shuffle) �� 4·���� CTR ���ܽ��", hw_ciphertext, 64);

    // ��֤��Ӳ�����Ż�·������Ƿ�һ��
    bool isConsistent = true;
    for (int i = 0; i < 64; i++) {
        if (sw_ciphertext[i] != hw_ciphertext[i]) {
            isConsistent = false;
            break;
        }
    }
    cout << "T-table�����AES-NI���" << (isConsistent ? "��ȫһ�£�" : "����ƫ�") << endl;

    // �Գ��Խ�����֤
    aes_ni.EncryptCTR_4x(hw_ciphertext, decrypted, 64, iv);
    printHex("���ܵõ������ģ�", decrypted, 64);
    bool ok = true;
    for (int i = 0; i < 64; i++) {
        if (plaintext[i] != decrypted[i]) {
            ok = false;
            break;
        }
    }
    cout << "����" << (ok ? "�ɹ����ӽ�����ȷ��" : "ʧ�ܣ�") << endl;

    return 0;
}