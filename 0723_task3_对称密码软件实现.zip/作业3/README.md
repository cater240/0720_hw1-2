# 作业3：AES-CTR模式优化实现与性能对比

本项目是《网络空间安全创新创业实践》作业三的完整交付物。

## 项目简介

高级加密标准(AES)在实际应用中广泛采用CTR（计数器）模式，以支持并行加密和流加密特性。本项目研究并实现了AES-CTR模式的两种主流优化策略：

1. **基于T-table的软件优化**：通过将SubBytes、ShiftRows以及MixColumns融合为32位查找表操作，大幅降低了每轮加密的运算开销。
2. **基于AES-NI硬件指令集的优化**：结合现代CPU的SIMD硬件指令集（AES-NI及SSSE3），实现了基于4路循环展开(4-Way Loop Unrolling)的CTR模式优化版本。

通过对比同一套密钥和初始向量(IV)环境下的加密结果，验证了软件优化与硬件优化结果的严格一致性，并通过加解密交叉验证了代码实现的正确性。

## 目录结构

```text
作业3/
├── 3.cpp                     # 实验核心代码（包含T-table和AES-NI实现）
├── README.md                 # 本文件
└── report/                   # 实验报告LaTeX源码及相关资源
    ├── report.tex            # 实验报告主文件
    ├── SDUstyle.sty          # LaTeX模板样式文件
    └── imgs/                 # 报告所用图片
```

## 环境要求

- **硬件环境**：支持SSSE3及AES-NI指令集的现代CPU（如Intel Core/AMD Ryzen系列），内存 $\ge$ 16GB。
- **操作系统**：Windows 11（Linux / macOS等环境亦可）。
- **软件环境**：C++ 编译器（支持C++11及以上标准，且支持 `<immintrin.h>` 和SIMD优化指令，如GCC, Clang, MSVC）。

## 编译与运行

由于代码中使用了硬件加速内联函数，需要使用支持硬件指令集优化的编译器选项进行编译（例如在GCC / Clang中需开启 `-maes` 和 `-mssse3` 指令集支持）。

### 命令行编译示例（GCC / Clang）：

```bash
# 开启AES和SSSE3指令集支持，并开启O3优化
g++ -O3 -maes -mssse3 3.cpp -o 3
```

### 运行程序：

```bash
# Windows
.\3.exe

# Linux / macOS
./3
```

## 预期输出

程序运行时将硬编码64字节测试明文（0x00至0x3f），分别采用T-table和AES-NI两个分支进行加密。最后判断双路密文是否一致，并进行对称解密测试。输出结果示例如下：

```text
AES加密双路优化验证
原始明文(64 bytes):
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f
...

T-table CTR密文(64 bytes):
...

AES-NI + SSSE3(Shuffle) 4路CTR密文(64 bytes):
...

T-table与AES-NI密文完全一致！
解密得到的明文(64 bytes):
00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f
...
解密成功：解密结果匹配
```

## 参考文献

- NIST. *Advanced Encryption Standard (AES)*. FIPS PUB 197, 2001.
- Shay Gueron. *Intel Advanced Encryption Standard (AES) New Instructions Set*. Intel Corporation, 2010.
