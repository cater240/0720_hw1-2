from pathlib import Path
import unittest

from bitcoin_parser.parser import ParseError, parse_block, parse_transaction
from bitcoin_parser.script import classify_output, disassemble


ROOT = Path(__file__).resolve().parent.parent


class BlockParserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.genesis_hex = (ROOT / "data" / "testnet3-genesis.hex").read_text(encoding="ascii")

    def test_testnet3_genesis_block(self):
        block = parse_block(self.genesis_hex)
        self.assertEqual(
            block["hash"],
            "000000000933ea01ad0ee984209779baaec3ced90fa3f408719526f8d77f4943",
        )
        self.assertEqual(block["transaction_count"], 1)
        self.assertTrue(block["merkle_root_valid"])
        self.assertTrue(block["header"]["proof_of_work_valid"])
        self.assertTrue(block["first_transaction_is_coinbase"])
        transaction = block["transactions"][0]
        self.assertEqual(transaction["txid"], block["header"]["merkle_root"])
        self.assertEqual(transaction["outputs"][0]["value_sats"], 5_000_000_000)
        self.assertEqual(transaction["outputs"][0]["type"], "p2pk")
        self.assertEqual(block["size"], 285)

    def test_rejects_trailing_block_data(self):
        with self.assertRaisesRegex(ParseError, "trailing"):
            parse_block(self.genesis_hex + "00")


class TransactionParserTests(unittest.TestCase):
    legacy = (
        "01000000"
        "01"
        "7b1eabe0209b1fe794124575ef807057c77ada2138ae4fa8d6c4de0398a14f3f"
        "00000000"
        "49"
        "48"
        "30450221008949f0cb400094ad2b5eb399d59d01c14d73d8fe6e96df1a7150de"
        "b388ab8935022079656090d7f6bac4c9a94e0aad311a4268e082a725f8aeae05"
        "73fb12ff866a5f01"
        "ffffffff"
        "01"
        "f0ca052a01000000"
        "19"
        "76a914cbc20a7664f2f69e5355aa427045bc15e7c6c77288ac"
        "00000000"
    )

    def test_legacy_transaction(self):
        transaction = parse_transaction(self.legacy)
        self.assertFalse(transaction["has_witness"])
        self.assertEqual(transaction["txid"], transaction["wtxid"])
        self.assertEqual(transaction["outputs"][0]["value_sats"], 4_999_990_000)
        self.assertEqual(transaction["outputs"][0]["type"], "p2pkh")
        self.assertTrue(transaction["outputs"][0]["address"].startswith(("m", "n")))

    def test_segwit_transaction_has_distinct_ids_and_weight(self):
        raw = (
            "02000000" "0001" "01" + "11" * 32 + "00000000" "00" "fdffffff"
            "01" "e803000000000000" "16" "0014" + "22" * 20
            + "02" "02" "aabb" "03" "ccddee" "00000000"
        )
        transaction = parse_transaction(raw)
        self.assertTrue(transaction["has_witness"])
        self.assertNotEqual(transaction["txid"], transaction["wtxid"])
        self.assertEqual(transaction["inputs"][0]["witness"], ["aabb", "ccddee"])
        self.assertEqual(transaction["outputs"][0]["type"], "p2wpkh")
        self.assertLess(transaction["base_size"], transaction["size"])
        self.assertEqual(transaction["vsize"], (transaction["weight"] + 3) // 4)

    def test_rejects_noncanonical_compact_size(self):
        with self.assertRaisesRegex(ParseError, "non-canonical"):
            parse_transaction("01000000fdfc00")

    def test_rejects_truncated_data(self):
        with self.assertRaisesRegex(ParseError, "need 32 bytes"):
            parse_transaction("0100000001")


class ScriptTests(unittest.TestCase):
    def test_disassembles_push_and_checksig(self):
        operations = disassemble(bytes.fromhex("02aabbac"))
        self.assertEqual(operations[0]["data"], "aabb")
        self.assertEqual(operations[1]["name"], "OP_CHECKSIG")

    def test_classifies_taproot(self):
        result = classify_output(bytes.fromhex("5120" + "33" * 32))
        self.assertEqual(result["type"], "p2tr")
        self.assertTrue(result["address"].startswith("tb1p"))

    def test_matches_bip173_testnet_address_vector(self):
        script = bytes.fromhex("0014751e76e8199196d454941c45d1b3a323f1433bd6")
        result = classify_output(script)
        self.assertEqual(result["type"], "p2wpkh")
        self.assertEqual(result["address"], "tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx")


if __name__ == "__main__":
    unittest.main()
