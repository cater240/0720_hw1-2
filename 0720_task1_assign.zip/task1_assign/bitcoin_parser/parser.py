"""Strict, trace-producing Bitcoin transaction and block parsers."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

from .script import classify_output, disassemble, script_asm, ScriptError


MAX_VECTOR_ITEMS = 4_000_000
DIFFICULTY_ONE_TARGET = 0xFFFF * 256 ** (0x1D - 3)


class ParseError(ValueError):
    """A malformed or truncated Bitcoin serialization."""


@dataclass
class Field:
    offset: int
    size: int
    path: str
    raw: str
    value: Any
    description: str

    @property
    def bits(self) -> str:
        if self.size == 0:
            return f"{self.offset * 8}"
        return f"{self.offset * 8}..{(self.offset + self.size) * 8 - 1}"

    def as_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["bits"] = self.bits
        return result


class Cursor:
    def __init__(self, data: bytes):
        self.data = data
        self.position = 0
        self.fields: list[Field] = []

    @property
    def remaining(self) -> int:
        return len(self.data) - self.position

    def read(self, size: int, path: str, value: Any, description: str) -> bytes:
        if size < 0 or self.position + size > len(self.data):
            raise ParseError(
                f"{path}: need {size} bytes at offset {self.position}, "
                f"only {self.remaining} remain"
            )
        start = self.position
        raw = self.data[start : start + size]
        self.position += size
        computed_value = value(raw) if callable(value) else value
        self.fields.append(Field(start, size, path, raw.hex(), computed_value, description))
        return raw

    def uint(self, size: int, path: str, description: str, *, signed: bool = False) -> int:
        raw = self.read(size, path, lambda item: int.from_bytes(item, "little", signed=signed), description)
        return int.from_bytes(raw, "little", signed=signed)

    def compact_size(self, path: str, description: str) -> int:
        start = self.position
        if self.remaining < 1:
            raise ParseError(f"{path}: missing CompactSize at offset {start}")
        prefix = self.data[self.position]
        if prefix < 0xFD:
            size = 1
            value = prefix
        else:
            size = {0xFD: 3, 0xFE: 5, 0xFF: 9}[prefix]
            if self.remaining < size:
                raise ParseError(f"{path}: truncated {size}-byte CompactSize at offset {start}")
            value = int.from_bytes(self.data[start + 1 : start + size], "little")
            minimum = {0xFD: 0xFD, 0xFE: 0x10000, 0xFF: 0x100000000}[prefix]
            if value < minimum:
                raise ParseError(f"{path}: non-canonical CompactSize value {value} at offset {start}")
        if value > MAX_VECTOR_ITEMS:
            raise ParseError(f"{path}: unreasonable item count/length {value}")
        self.read(size, path, value, description)
        return value


def hash256(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def _read_script(cursor: Cursor, size: int, path: str, description: str) -> tuple[bytes, str, list[dict[str, Any]]]:
    raw = cursor.read(size, path, lambda item: item.hex(), description)
    try:
        return raw, script_asm(raw), disassemble(raw)
    except ScriptError as error:
        return raw, f"<invalid: {error}>", []


def _parse_transaction(cursor: Cursor, path: str, network: str) -> dict[str, Any]:
    start = cursor.position
    version_start = cursor.position
    version = cursor.uint(4, f"{path}.version", "signed transaction format version", signed=True)

    has_witness = cursor.remaining >= 2 and cursor.data[cursor.position] == 0 and cursor.data[cursor.position + 1] != 0
    if has_witness:
        cursor.uint(1, f"{path}.marker", "SegWit marker (must be 0)")
        flag = cursor.uint(1, f"{path}.flag", "SegWit serialization flag")
    else:
        flag = 0

    vin_count_start = cursor.position
    input_count = cursor.compact_size(f"{path}.input_count", "number of transaction inputs")
    if input_count == 0:
        raise ParseError(f"{path}: transaction has no inputs")
    inputs: list[dict[str, Any]] = []
    for index in range(input_count):
        input_path = f"{path}.inputs[{index}]"
        previous_hash = cursor.read(
            32,
            f"{input_path}.previous_txid",
            lambda raw: raw[::-1].hex(),
            "previous transaction hash (serialized in internal byte order)",
        )
        previous_index = cursor.uint(4, f"{input_path}.previous_vout", "previous output index")
        script_length = cursor.compact_size(
            f"{input_path}.script_sig_length", "signature/unlocking script byte length"
        )
        script, asm, operations = _read_script(
            cursor,
            script_length,
            f"{input_path}.script_sig",
            "signature/unlocking Script bytecode",
        )
        sequence = cursor.uint(4, f"{input_path}.sequence", "input sequence number")
        inputs.append(
            {
                "previous_txid": previous_hash[::-1].hex(),
                "previous_vout": previous_index,
                "script_sig": script.hex(),
                "script_sig_asm": asm,
                "script_sig_operations": operations,
                "sequence": sequence,
                "witness": [],
            }
        )

    output_count = cursor.compact_size(f"{path}.output_count", "number of transaction outputs")
    outputs: list[dict[str, Any]] = []
    for index in range(output_count):
        output_path = f"{path}.outputs[{index}]"
        value = cursor.uint(8, f"{output_path}.value", "output value in satoshis")
        script_length = cursor.compact_size(
            f"{output_path}.script_pubkey_length", "locking script byte length"
        )
        script = cursor.read(
            script_length,
            f"{output_path}.script_pubkey",
            lambda raw: raw.hex(),
            "locking Script bytecode",
        )
        outputs.append(
            {
                "value_sats": value,
                "script_pubkey": script.hex(),
                **classify_output(script, network),
            }
        )

    base_end = cursor.position
    witness_start = cursor.position
    if has_witness:
        for index, tx_input in enumerate(inputs):
            input_path = f"{path}.inputs[{index}].witness"
            item_count = cursor.compact_size(f"{input_path}.item_count", "witness stack item count")
            witness: list[str] = []
            for item_index in range(item_count):
                item_path = f"{input_path}[{item_index}]"
                item_length = cursor.compact_size(f"{item_path}.length", "witness item byte length")
                item = cursor.read(
                    item_length,
                    f"{item_path}.data",
                    lambda raw: raw.hex(),
                    "witness stack item",
                )
                witness.append(item.hex())
            tx_input["witness"] = witness
    witness_end = cursor.position

    locktime_start = cursor.position
    locktime = cursor.uint(4, f"{path}.locktime", "absolute block-height or Unix-time lock")
    end = cursor.position
    raw = cursor.data[start:end]
    if has_witness:
        stripped = (
            cursor.data[version_start : version_start + 4]
            + cursor.data[vin_count_start:base_end]
            + cursor.data[locktime_start:end]
        )
    else:
        stripped = raw

    txid = hash256(stripped)[::-1].hex()
    wtxid = hash256(raw)[::-1].hex()
    base_size = len(stripped)
    total_size = len(raw)
    weight = base_size * 3 + total_size
    coinbase = (
        len(inputs) == 1
        and inputs[0]["previous_txid"] == "00" * 32
        and inputs[0]["previous_vout"] == 0xFFFFFFFF
    )
    return {
        "txid": txid,
        "wtxid": wtxid,
        "version": version,
        "has_witness": has_witness,
        "witness_flag": flag,
        "coinbase": coinbase,
        "inputs": inputs,
        "outputs": outputs,
        "locktime": locktime,
        "size": total_size,
        "base_size": base_size,
        "witness_size": (witness_end - witness_start + 2) if has_witness else 0,
        "weight": weight,
        "vsize": (weight + 3) // 4,
        "raw": raw.hex(),
    }


def _decode_hex(raw_hex: str) -> bytes:
    compact = "".join(raw_hex.split())
    if not compact:
        raise ParseError("input is empty")
    try:
        return bytes.fromhex(compact)
    except ValueError as error:
        raise ParseError(f"invalid hexadecimal input: {error}") from error


def parse_transaction(raw: bytes | str, network: str = "testnet") -> dict[str, Any]:
    data = _decode_hex(raw) if isinstance(raw, str) else raw
    cursor = Cursor(data)
    transaction = _parse_transaction(cursor, "tx", network)
    if cursor.remaining:
        raise ParseError(f"transaction has {cursor.remaining} trailing bytes at offset {cursor.position}")
    transaction["fields"] = [field.as_dict() for field in cursor.fields]
    return transaction


def compact_target(bits: int) -> int:
    exponent = bits >> 24
    coefficient = bits & 0x007FFFFF
    if bits & 0x00800000:
        return 0
    if exponent <= 3:
        return coefficient >> (8 * (3 - exponent))
    return coefficient << (8 * (exponent - 3))


def merkle_root(txids: list[str]) -> bytes:
    if not txids:
        raise ParseError("cannot calculate a Merkle root without transactions")
    row = [bytes.fromhex(txid)[::-1] for txid in txids]
    while len(row) > 1:
        if len(row) % 2:
            row.append(row[-1])
        row = [hash256(row[index] + row[index + 1]) for index in range(0, len(row), 2)]
    return row[0]


def parse_block(raw: bytes | str, network: str = "testnet") -> dict[str, Any]:
    data = _decode_hex(raw) if isinstance(raw, str) else raw
    cursor = Cursor(data)
    if len(data) < 81:
        raise ParseError(f"serialized block is only {len(data)} bytes; need at least 81")
    header_start = cursor.position
    version = cursor.uint(4, "block.header.version", "signed block version", signed=True)
    previous_hash_raw = cursor.read(
        32,
        "block.header.previous_hash",
        lambda item: item[::-1].hex(),
        "previous block hash (internal byte order)",
    )
    merkle_raw = cursor.read(
        32,
        "block.header.merkle_root",
        lambda item: item[::-1].hex(),
        "transaction Merkle root (internal byte order)",
    )
    timestamp = cursor.uint(4, "block.header.timestamp", "block timestamp as Unix epoch seconds")
    bits = cursor.uint(4, "block.header.bits", "compact proof-of-work target")
    nonce = cursor.uint(4, "block.header.nonce", "proof-of-work nonce")
    header_end = cursor.position
    header = data[header_start:header_end]
    digest = hash256(header)
    block_hash = digest[::-1].hex()
    target = compact_target(bits)
    proof_value = int.from_bytes(digest, "little")

    transaction_count_size_start = cursor.position
    transaction_count = cursor.compact_size("block.transaction_count", "number of block transactions")
    if transaction_count == 0:
        raise ParseError("block contains no transactions")
    transaction_count_size = cursor.position - transaction_count_size_start
    transactions = [
        _parse_transaction(cursor, f"block.transactions[{index}]", network)
        for index in range(transaction_count)
    ]
    if cursor.remaining:
        raise ParseError(f"block has {cursor.remaining} trailing bytes at offset {cursor.position}")

    calculated_merkle = merkle_root([transaction["txid"] for transaction in transactions])
    stripped_size = 80 + transaction_count_size + sum(tx["base_size"] for tx in transactions)
    weight = stripped_size * 3 + len(data)
    try:
        utc_time = datetime.fromtimestamp(timestamp, timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        utc_time = None
    return {
        "hash": block_hash,
        "header": {
            "version": version,
            "previous_hash": previous_hash_raw[::-1].hex(),
            "merkle_root": merkle_raw[::-1].hex(),
            "timestamp": timestamp,
            "timestamp_utc": utc_time,
            "bits": f"0x{bits:08x}",
            "nonce": nonce,
            "target": f"{target:064x}",
            "proof_value": f"{proof_value:064x}",
            "proof_of_work_valid": bool(target and proof_value <= target),
            "difficulty": (DIFFICULTY_ONE_TARGET / target) if target else None,
        },
        "transaction_count": transaction_count,
        "transactions": transactions,
        "merkle_root_calculated": calculated_merkle[::-1].hex(),
        "merkle_root_valid": calculated_merkle == merkle_raw,
        "first_transaction_is_coinbase": transactions[0]["coinbase"],
        "size": len(data),
        "stripped_size": stripped_size,
        "weight": weight,
        "vsize": (weight + 3) // 4,
        "fields": [field.as_dict() for field in cursor.fields],
    }

