"""Command-line interface for parsing and test-network RPC operations."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from .parser import ParseError, parse_block, parse_transaction
from .rpc import BitcoinRpc, RpcError


PROJECT_ROOT = Path(__file__).resolve().parent.parent
GENESIS_FILE = PROJECT_ROOT / "data" / "testnet3-genesis.hex"


def _source_hex(arguments: argparse.Namespace) -> str:
    if getattr(arguments, "hex", None):
        return arguments.hex
    try:
        return Path(arguments.file).read_text(encoding="utf-8")
    except OSError as error:
        raise ParseError(f"cannot read {arguments.file!r}: {error}") from error


def _short(value: Any, limit: int = 58) -> str:
    if isinstance(value, (dict, list)):
        rendered = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    else:
        rendered = str(value)
    return rendered if len(rendered) <= limit else rendered[: limit - 3] + "..."


def _print_fields(fields: list[dict[str, Any]], every_byte: bool) -> None:
    print("\nBYTE MAP")
    if every_byte:
        print(f"{'BYTE':>6}  {'BITS':>12}  {'HEX':>3}  FIELD")
        for field in fields:
            raw = bytes.fromhex(field["raw"])
            for relative, octet in enumerate(raw):
                offset = field["offset"] + relative
                print(f"{offset:6d}  {offset * 8:5d}..{offset * 8 + 7:<5d}  {octet:02x}   {field['path']}")
        return

    print(f"{'OFFSET':>10}  {'BITS':>15}  {'SIZE':>5}  {'FIELD':<45} VALUE")
    for field in fields:
        end = field["offset"] + field["size"] - 1
        offset = str(field["offset"]) if field["size"] == 1 else f"{field['offset']}..{end}"
        print(
            f"{offset:>10}  {field['bits']:>15}  {field['size']:5d}  "
            f"{field['path']:<45} {_short(field['value'])}"
        )
        print(f"{'':>10}  hex={field['raw']}  # {field['description']}")


def _print_transaction(result: dict[str, Any], fields: bool = True, every_byte: bool = False) -> None:
    print("TRANSACTION")
    print(f"txid:       {result['txid']}")
    print(f"wtxid:      {result['wtxid']}")
    print(f"format:     version {result['version']}, {'SegWit' if result['has_witness'] else 'legacy'}")
    print(
        f"size:       {result['size']} bytes, {result['weight']} WU, "
        f"{result['vsize']} vbytes"
    )
    print(f"coinbase:   {result['coinbase']}")
    print(f"locktime:   {result['locktime']}")
    print(f"inputs:     {len(result['inputs'])}")
    for index, tx_input in enumerate(result["inputs"]):
        print(
            f"  [{index}] {tx_input['previous_txid']}:{tx_input['previous_vout']} "
            f"sequence=0x{tx_input['sequence']:08x}"
        )
        print(f"      scriptSig: {tx_input['script_sig_asm'] or '<empty>'}")
        if tx_input["witness"]:
            print(f"      witness:   {' | '.join(tx_input['witness'])}")
    print(f"outputs:    {len(result['outputs'])}")
    for index, output in enumerate(result["outputs"]):
        address = f" address={output['address']}" if output.get("address") else ""
        print(f"  [{index}] {output['value_sats']} sat, {output['type']}{address}")
        print(f"      scriptPubKey: {output['asm'] or '<empty>'}")
    if fields:
        _print_fields(result["fields"], every_byte)


def _print_block(result: dict[str, Any], every_byte: bool = False) -> None:
    header = result["header"]
    print("BLOCK")
    print(f"hash:        {result['hash']}")
    print(f"previous:    {header['previous_hash']}")
    print(f"merkle root: {header['merkle_root']}")
    print(f"time:        {header['timestamp']} ({header['timestamp_utc']})")
    print(f"bits/nonce:  {header['bits']} / {header['nonce']}")
    print(f"target:      {header['target']}")
    print(f"PoW valid:   {header['proof_of_work_valid']}")
    print(f"transactions:{result['transaction_count']}")
    print(f"Merkle valid:{result['merkle_root_valid']}")
    print(
        f"size:        {result['size']} bytes, {result['weight']} WU, "
        f"{result['vsize']} vbytes"
    )
    for index, transaction in enumerate(result["transactions"]):
        print(
            f"  tx[{index}] {transaction['txid']} | "
            f"{len(transaction['inputs'])} in, {len(transaction['outputs'])} out, "
            f"{transaction['size']} bytes"
        )
    _print_fields(result["fields"], every_byte)


def _emit(result: dict[str, Any], arguments: argparse.Namespace, kind: str) -> None:
    if arguments.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif kind == "block":
        _print_block(result, arguments.bytes)
    else:
        _print_transaction(result, every_byte=arguments.bytes)


def _rpc(arguments: argparse.Namespace) -> BitcoinRpc:
    return BitcoinRpc(
        url=arguments.rpc_url,
        username=arguments.rpc_user,
        password=arguments.rpc_password,
        cookie_file=arguments.rpc_cookie,
        timeout=arguments.rpc_timeout,
    )


def _confirm_mutation(arguments: argparse.Namespace) -> None:
    if not arguments.yes:
        raise RpcError("refusing to send: inspect the values, then repeat with --yes")


def _run(arguments: argparse.Namespace) -> None:
    if arguments.command == "tx":
        _emit(parse_transaction(_source_hex(arguments), arguments.network), arguments, "tx")
    elif arguments.command == "block":
        _emit(parse_block(_source_hex(arguments), arguments.network), arguments, "block")
    elif arguments.command == "demo":
        raw = GENESIS_FILE.read_text(encoding="ascii")
        _emit(parse_block(raw, "testnet"), arguments, "block")
    elif arguments.command == "fetch-tx":
        rpc = _rpc(arguments)
        params: list[Any] = [arguments.txid, False]
        if arguments.block_hash:
            params.append(arguments.block_hash)
        raw = rpc.call("getrawtransaction", *params)
        _emit(parse_transaction(raw, arguments.network), arguments, "tx")
    elif arguments.command == "fetch-block":
        rpc = _rpc(arguments)
        block_hash = (
            rpc.call("getblockhash", int(arguments.block))
            if arguments.block.isdecimal()
            else arguments.block
        )
        raw = rpc.call("getblock", block_hash, 0)
        _emit(parse_block(raw, arguments.network), arguments, "block")
    elif arguments.command == "broadcast":
        _confirm_mutation(arguments)
        raw = _source_hex(arguments)
        parsed = parse_transaction(raw, arguments.network)
        rpc = _rpc(arguments)
        chain = rpc.require_test_chain()
        txid = rpc.call("sendrawtransaction", "".join(raw.split()))
        parsed["broadcast"] = {"chain": chain, "txid": txid, "method": "sendrawtransaction"}
        if not arguments.json:
            print(f"broadcast on {chain}: {txid}")
        _emit(parsed, arguments, "tx")
    elif arguments.command == "send":
        _confirm_mutation(arguments)
        if arguments.amount_sats <= 0:
            raise RpcError("amount-sats must be positive")
        rpc = _rpc(arguments)
        chain = rpc.require_test_chain()
        whole, fraction = divmod(arguments.amount_sats, 100_000_000)
        amount_btc = f"{whole}.{fraction:08d}"
        txid = rpc.call("sendtoaddress", arguments.address, amount_btc, "task1 byte parser")
        wallet_transaction = rpc.call("gettransaction", txid)
        raw = wallet_transaction.get("hex")
        if not raw:
            raise RpcError(f"wallet sent {txid}, but gettransaction returned no raw hex")
        parsed = parse_transaction(raw, arguments.network)
        parsed["broadcast"] = {"chain": chain, "txid": txid, "method": "sendtoaddress"}
        if not arguments.json:
            print(f"sent on {chain}: {txid}")
        _emit(parsed, arguments, "tx")
    else:
        raise AssertionError(f"unknown command: {arguments.command}")


def _add_output_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    parser.add_argument("--bytes", action="store_true", help="print one line for every serialized byte")
    parser.add_argument(
        "--network",
        choices=("mainnet", "testnet", "regtest"),
        default="testnet",
        help="address encoding used when classifying scripts (default: testnet)",
    )


def _add_source(parser: argparse.ArgumentParser) -> None:
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--hex", help="serialized hexadecimal data")
    source.add_argument("--file", help="file containing serialized hexadecimal data")


def _add_rpc_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--rpc-url",
        default=os.getenv("BTC_RPC_URL", "http://127.0.0.1:18332"),
        help="Bitcoin Core JSON-RPC URL; include /wallet/NAME when needed",
    )
    parser.add_argument("--rpc-user", default=None, help="RPC user (or BTC_RPC_USER)")
    parser.add_argument("--rpc-password", default=None, help="RPC password (or BTC_RPC_PASSWORD)")
    parser.add_argument("--rpc-cookie", default=None, help="path to .cookie (or BTC_RPC_COOKIE)")
    parser.add_argument("--rpc-timeout", type=float, default=30.0)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bitcoin-parser",
        description="Parse Bitcoin transactions/blocks byte by byte and use Bitcoin Core testnet RPC.",
    )
    commands = parser.add_subparsers(dest="command", required=True)

    tx = commands.add_parser("tx", help="parse one raw transaction")
    _add_source(tx)
    _add_output_options(tx)

    block = commands.add_parser("block", help="parse one complete serialized block")
    _add_source(block)
    _add_output_options(block)

    demo = commands.add_parser("demo", help="parse the bundled testnet3 genesis block offline")
    _add_output_options(demo)

    fetch_tx = commands.add_parser("fetch-tx", help="fetch and parse a transaction through Bitcoin Core")
    fetch_tx.add_argument("txid")
    fetch_tx.add_argument("--block-hash", help="block hint, avoiding a txindex requirement")
    _add_rpc_options(fetch_tx)
    _add_output_options(fetch_tx)

    fetch_block = commands.add_parser("fetch-block", help="fetch and parse a block hash or height")
    fetch_block.add_argument("block", help="block hash or decimal height")
    _add_rpc_options(fetch_block)
    _add_output_options(fetch_block)

    broadcast = commands.add_parser("broadcast", help="broadcast an already-signed raw transaction")
    _add_source(broadcast)
    _add_rpc_options(broadcast)
    _add_output_options(broadcast)
    broadcast.add_argument("--yes", action="store_true", help="confirm the test-network broadcast")

    send = commands.add_parser("send", help="let a loaded Bitcoin Core wallet create and send a payment")
    send.add_argument("--address", required=True, help="test-network destination address")
    send.add_argument("--amount-sats", required=True, type=int, help="exact amount to send, in satoshis")
    _add_rpc_options(send)
    _add_output_options(send)
    send.add_argument("--yes", action="store_true", help="confirm the test-network wallet spend")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    arguments = parser.parse_args(argv)
    try:
        _run(arguments)
        return 0
    except (ParseError, RpcError, OSError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
