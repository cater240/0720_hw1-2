"""Bitcoin Script disassembly and standard output-script recognition."""

from __future__ import annotations

import hashlib
from typing import Any


class ScriptError(ValueError):
    """Raised when a push operation runs past the end of a script."""


OPCODES = {
    0x00: "OP_0",
    0x4C: "OP_PUSHDATA1",
    0x4D: "OP_PUSHDATA2",
    0x4E: "OP_PUSHDATA4",
    0x4F: "OP_1NEGATE",
    0x50: "OP_RESERVED",
    0x51: "OP_1",
    0x52: "OP_2",
    0x53: "OP_3",
    0x54: "OP_4",
    0x55: "OP_5",
    0x56: "OP_6",
    0x57: "OP_7",
    0x58: "OP_8",
    0x59: "OP_9",
    0x5A: "OP_10",
    0x5B: "OP_11",
    0x5C: "OP_12",
    0x5D: "OP_13",
    0x5E: "OP_14",
    0x5F: "OP_15",
    0x60: "OP_16",
    0x61: "OP_NOP",
    0x63: "OP_IF",
    0x64: "OP_NOTIF",
    0x67: "OP_ELSE",
    0x68: "OP_ENDIF",
    0x69: "OP_VERIFY",
    0x6A: "OP_RETURN",
    0x6B: "OP_TOALTSTACK",
    0x6C: "OP_FROMALTSTACK",
    0x73: "OP_IFDUP",
    0x74: "OP_DEPTH",
    0x75: "OP_DROP",
    0x76: "OP_DUP",
    0x77: "OP_NIP",
    0x78: "OP_OVER",
    0x79: "OP_PICK",
    0x7A: "OP_ROLL",
    0x7B: "OP_ROT",
    0x7C: "OP_SWAP",
    0x7D: "OP_TUCK",
    0x82: "OP_SIZE",
    0x87: "OP_EQUAL",
    0x88: "OP_EQUALVERIFY",
    0x8B: "OP_1ADD",
    0x8C: "OP_1SUB",
    0x8F: "OP_NEGATE",
    0x90: "OP_ABS",
    0x91: "OP_NOT",
    0x92: "OP_0NOTEQUAL",
    0x93: "OP_ADD",
    0x94: "OP_SUB",
    0x9A: "OP_BOOLAND",
    0x9B: "OP_BOOLOR",
    0x9C: "OP_NUMEQUAL",
    0x9D: "OP_NUMEQUALVERIFY",
    0x9E: "OP_NUMNOTEQUAL",
    0x9F: "OP_LESSTHAN",
    0xA0: "OP_GREATERTHAN",
    0xA1: "OP_LESSTHANOREQUAL",
    0xA2: "OP_GREATERTHANOREQUAL",
    0xA3: "OP_MIN",
    0xA4: "OP_MAX",
    0xA5: "OP_WITHIN",
    0xA6: "OP_RIPEMD160",
    0xA7: "OP_SHA1",
    0xA8: "OP_SHA256",
    0xA9: "OP_HASH160",
    0xAA: "OP_HASH256",
    0xAB: "OP_CODESEPARATOR",
    0xAC: "OP_CHECKSIG",
    0xAD: "OP_CHECKSIGVERIFY",
    0xAE: "OP_CHECKMULTISIG",
    0xAF: "OP_CHECKMULTISIGVERIFY",
    0xB0: "OP_NOP1",
    0xB1: "OP_CHECKLOCKTIMEVERIFY",
    0xB2: "OP_CHECKSEQUENCEVERIFY",
    0xBA: "OP_CHECKSIGADD",
}


def _hash256(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def _base58check(version: int, payload: bytes) -> str:
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    raw = bytes([version]) + payload
    raw += _hash256(raw)[:4]
    number = int.from_bytes(raw, "big")
    encoded = ""
    while number:
        number, remainder = divmod(number, 58)
        encoded = alphabet[remainder] + encoded
    zeroes = len(raw) - len(raw.lstrip(b"\x00"))
    return "1" * zeroes + (encoded or "1")


def _bech32_polymod(values: list[int]) -> int:
    generators = (0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3)
    checksum = 1
    for value in values:
        top = checksum >> 25
        checksum = ((checksum & 0x1FFFFFF) << 5) ^ value
        for bit, generator in enumerate(generators):
            if (top >> bit) & 1:
                checksum ^= generator
    return checksum


def _hrp_expand(hrp: str) -> list[int]:
    return [ord(char) >> 5 for char in hrp] + [0] + [ord(char) & 31 for char in hrp]


def _convert_bits(data: bytes, from_bits: int, to_bits: int) -> list[int]:
    accumulator = 0
    bit_count = 0
    result: list[int] = []
    mask = (1 << to_bits) - 1
    for value in data:
        accumulator = (accumulator << from_bits) | value
        bit_count += from_bits
        while bit_count >= to_bits:
            bit_count -= to_bits
            result.append((accumulator >> bit_count) & mask)
    if bit_count:
        result.append((accumulator << (to_bits - bit_count)) & mask)
    return result


def _segwit_address(hrp: str, version: int, program: bytes) -> str:
    charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    values = [version] + _convert_bits(program, 8, 5)
    constant = 1 if version == 0 else 0x2BC830A3
    polymod = _bech32_polymod(_hrp_expand(hrp) + values + [0] * 6) ^ constant
    checksum = [(polymod >> (5 * (5 - index))) & 31 for index in range(6)]
    return hrp + "1" + "".join(charset[value] for value in values + checksum)


def disassemble(script: bytes) -> list[dict[str, Any]]:
    """Turn serialized Script into opcodes while retaining byte offsets."""
    operations: list[dict[str, Any]] = []
    position = 0
    while position < len(script):
        start = position
        opcode = script[position]
        position += 1
        data_length: int | None = None
        length_bytes = 0

        if 1 <= opcode <= 75:
            data_length = opcode
            name = f"PUSHBYTES_{opcode}"
        elif opcode in (0x4C, 0x4D, 0x4E):
            length_bytes = {0x4C: 1, 0x4D: 2, 0x4E: 4}[opcode]
            if position + length_bytes > len(script):
                raise ScriptError(f"truncated {OPCODES[opcode]} length at script byte {start}")
            data_length = int.from_bytes(script[position : position + length_bytes], "little")
            position += length_bytes
            name = OPCODES[opcode]
        else:
            name = OPCODES.get(opcode, f"OP_UNKNOWN_0x{opcode:02x}")

        operation: dict[str, Any] = {
            "offset": start,
            "opcode": f"0x{opcode:02x}",
            "name": name,
        }
        if data_length is not None:
            end = position + data_length
            if end > len(script):
                raise ScriptError(
                    f"{name} at script byte {start} requests {data_length} bytes, "
                    f"but only {len(script) - position} remain"
                )
            operation["data_length"] = data_length
            operation["data"] = script[position:end].hex()
            position = end
        operation["size"] = position - start
        operations.append(operation)
    return operations


def script_asm(script: bytes) -> str:
    parts = []
    for operation in disassemble(script):
        if "data" in operation:
            parts.append(f"{operation['name']}[{operation['data']}]")
        else:
            parts.append(operation["name"])
    return " ".join(parts)


def classify_output(script: bytes, network: str = "testnet") -> dict[str, Any]:
    """Recognize standard scriptPubKey templates and derive their address."""
    if network not in {"mainnet", "testnet", "regtest"}:
        raise ValueError(f"unsupported network: {network}")
    p2pkh_version = 0x00 if network == "mainnet" else 0x6F
    p2sh_version = 0x05 if network == "mainnet" else 0xC4
    hrp = {"mainnet": "bc", "testnet": "tb", "regtest": "bcrt"}[network]

    result: dict[str, Any]
    if len(script) == 25 and script[:3] == b"\x76\xa9\x14" and script[-2:] == b"\x88\xac":
        payload = script[3:23]
        result = {"type": "p2pkh", "address": _base58check(p2pkh_version, payload)}
    elif len(script) == 23 and script[:2] == b"\xa9\x14" and script[-1:] == b"\x87":
        payload = script[2:22]
        result = {"type": "p2sh", "address": _base58check(p2sh_version, payload)}
    elif len(script) in (35, 67) and script[0] in (33, 65) and script[-1] == 0xAC:
        result = {"type": "p2pk", "public_key": script[1:-1].hex()}
    elif script[:1] == b"\x6a":
        result = {"type": "op_return"}
    elif len(script) >= 4 and script[0] in (0x00, *range(0x51, 0x61)):
        version = 0 if script[0] == 0 else script[0] - 0x50
        program_length = script[1]
        program = script[2:]
        if 2 <= program_length <= 40 and len(program) == program_length:
            if version == 0 and program_length == 20:
                script_type = "p2wpkh"
            elif version == 0 and program_length == 32:
                script_type = "p2wsh"
            elif version == 1 and program_length == 32:
                script_type = "p2tr"
            else:
                script_type = f"witness_v{version}"
            result = {
                "type": script_type,
                "witness_version": version,
                "witness_program": program.hex(),
                "address": _segwit_address(hrp, version, program),
            }
        else:
            result = {"type": "nonstandard"}
    elif script[-1:] in (b"\xae", b"\xaf"):
        result = {"type": "multisig_or_nonstandard"}
    elif not script:
        result = {"type": "empty"}
    else:
        result = {"type": "nonstandard"}

    try:
        result["asm"] = script_asm(script)
        result["operations"] = disassemble(script)
    except ScriptError as error:
        result["asm"] = f"<invalid: {error}>"
        result["operations"] = []
        result["script_error"] = str(error)
    return result

