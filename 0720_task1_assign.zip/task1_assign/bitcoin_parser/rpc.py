"""Small Bitcoin Core JSON-RPC client built on the Python standard library."""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class RpcError(RuntimeError):
    """A transport error or JSON-RPC error returned by Bitcoin Core."""


class BitcoinRpc:
    def __init__(
        self,
        url: str = "http://127.0.0.1:18332",
        username: str | None = None,
        password: str | None = None,
        cookie_file: str | None = None,
        timeout: float = 30.0,
    ):
        self.url = url
        self.timeout = timeout
        username = username if username is not None else os.getenv("BTC_RPC_USER")
        password = password if password is not None else os.getenv("BTC_RPC_PASSWORD")
        cookie_file = cookie_file if cookie_file is not None else os.getenv("BTC_RPC_COOKIE")
        if cookie_file:
            try:
                cookie = Path(cookie_file).read_text(encoding="utf-8").strip()
                username, password = cookie.split(":", 1)
            except (OSError, ValueError) as error:
                raise RpcError(f"cannot read RPC cookie {cookie_file!r}: {error}") from error
        self.username = username
        self.password = password

    def call(self, method: str, *params: Any) -> Any:
        body = json.dumps(
            {"jsonrpc": "1.0", "id": "task1", "method": method, "params": list(params)},
            separators=(",", ":"),
        ).encode("utf-8")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.username is not None or self.password is not None:
            credentials = f"{self.username or ''}:{self.password or ''}".encode("utf-8")
            headers["Authorization"] = "Basic " + base64.b64encode(credentials).decode("ascii")
        request = Request(self.url, data=body, headers=headers, method="POST")
        try:
            with urlopen(request, timeout=self.timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RpcError(f"Bitcoin Core RPC HTTP {error.code}: {detail}") from error
        except (URLError, OSError, json.JSONDecodeError) as error:
            raise RpcError(f"cannot call Bitcoin Core at {self.url}: {error}") from error
        if not isinstance(payload, dict):
            raise RpcError(f"RPC {method} returned an unexpected response")
        if payload.get("error"):
            rpc_error = payload["error"]
            raise RpcError(f"RPC {method} failed ({rpc_error.get('code')}): {rpc_error.get('message')}")
        return payload.get("result")

    def require_test_chain(self) -> str:
        chain = self.call("getblockchaininfo").get("chain")
        if chain not in {"test", "testnet4", "signet", "regtest"}:
            raise RpcError(
                f"refusing transaction operation on chain {chain!r}; "
                "connect this task to testnet, testnet4, signet, or regtest"
            )
        return str(chain)
